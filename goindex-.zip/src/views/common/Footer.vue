<template>
  <footer class="footer">
    <div class="columns is-mobile is-centered">
      <div class="field is-grouped is-grouped-multiline">
        <div class="control">
          <div class="tags has-addons">
            <a
              class="tag is-dark"
              href="https://github.com/Aicirou/goindex-theme-acrou"
            >goindex-theme-acrou</a>
            <span class="tag is-light">
              MIT &nbsp;
              <span class="icon">
                <i class="fa fa-github"></i>
              </span>
            </span>
          </div>
        </div>
      </div>
    </div>
  </footer>
</template>

<script>
export default {
  props: {},
  watch: {},
  data: function () {
    return {
      content: ""
    };
  },
  components: {},
  methods: {}
};
</script>